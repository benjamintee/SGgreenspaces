oex export
==========

Generated:        2026-11-04 10:14:34 UTC
oex version:      0.4.19
Project:          https://github.com/osgeonepal/oex

Country (ISO3):   SGP
Boundary:         geoBoundaries gbOpen ADM0 (buffered +10000m, simplified 1000m)
Bounding box:     (103.5163, 1.0986, 104.1729, 1.5612)

Dataset:          roads
Format:           GeoPackage (gpkg)
Features:         369,461

Source:           OpenStreetMap contributors
Source URL:       https://www.openstreetmap.org/
Snapshot:         2026-11-03
License:          Open Database License (ODC-ODbL)
License URL:      https://opendatacommons.org/licenses/odbl/1-0/

About the source
  OpenStreetMap is a community-edited geographic dataset of the world. Country
  features are extracted from the source PBF via quackosm with the union of
  all category tag filters; per-category exports apply tag predicates at query
  time.

Notes
  - GeoPackage holds all geometry types in a single .gpkg file.
  - Recommended for QGIS, ArcGIS, GDAL/OGR.

Feedback:         https://github.com/osgeonepal/oex/issues
Engine: planet